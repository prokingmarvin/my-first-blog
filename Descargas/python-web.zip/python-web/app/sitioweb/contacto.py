# -*- coding: utf-8 -*-

def saludo():
    salida =  "<p>Este es la página de contacto <b>"
    return salida
